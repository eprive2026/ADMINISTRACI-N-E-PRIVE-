-- Configurar almacenamiento de fotos de É. Privé.
-- Ejecutar en Supabase > SQL Editor. No modifica las tablas existentes.
insert into storage.buckets (id,name,public)
values ('eprive-photos','eprive-photos',true)
on conflict (id) do update set public=true;

drop policy if exists "EPrive admin upload photos" on storage.objects;
create policy "EPrive admin upload photos" on storage.objects
for insert to authenticated with check (
 bucket_id='eprive-photos' and exists (
  select 1 from public.app_users where user_id=auth.uid() and role='admin'
 )
);
drop policy if exists "EPrive admin update photos" on storage.objects;
create policy "EPrive admin update photos" on storage.objects
for update to authenticated using (
 bucket_id='eprive-photos' and exists (
  select 1 from public.app_users where user_id=auth.uid() and role='admin'
 )
) with check (
 bucket_id='eprive-photos' and exists (
  select 1 from public.app_users where user_id=auth.uid() and role='admin'
 )
);
drop policy if exists "EPrive admin delete photos" on storage.objects;
create policy "EPrive admin delete photos" on storage.objects
for delete to authenticated using (
 bucket_id='eprive-photos' and exists (
  select 1 from public.app_users where user_id=auth.uid() and role='admin'
 )
);
drop policy if exists "EPrive public read photos" on storage.objects;
create policy "EPrive public read photos" on storage.objects
for select to public using (bucket_id='eprive-photos');
