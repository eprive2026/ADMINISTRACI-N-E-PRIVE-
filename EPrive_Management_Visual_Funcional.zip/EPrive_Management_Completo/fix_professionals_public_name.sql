-- É. PRIVÉ MANAGEMENT · reparación segura de la columna de nombre público
-- Ejecutar UNA SOLA VEZ en Supabase > SQL Editor.
-- No borra ni modifica las fichas existentes salvo rellenar public_name cuando esté vacío.

alter table public.professionals
  add column if not exists public_name text;

do $$
declare
  source_column text;
begin
  -- Recupera el nombre existente si la tabla usa otro nombre de columna.
  foreach source_column in array array['full_name', 'name', 'display_name'] loop
    if exists (
      select 1
      from information_schema.columns
      where table_schema = 'public'
        and table_name = 'professionals'
        and column_name = source_column
    ) then
      execute format(
        'update public.professionals set public_name = %I where public_name is null or btrim(public_name) = ''''',
        source_column
      );
      exit;
    end if;
  end loop;
end $$;
