-- Ranking compartido seguro para profesionales.
-- Ejecuta este bloque en Supabase > SQL Editor.
-- Devuelve únicamente nombre público, porcentaje de objetivo y servicios completados.
-- No devuelve tarifas, importes ni datos privados de ninguna profesional.

create or replace function public.get_professional_ranking()
returns table (
  public_name text,
  objective_percent numeric,
  completed_services bigint
)
language sql
stable
security definer
set search_path = public
as $$
  select
    p.public_name::text,
    case
      when coalesce(g.target_amount, 0) > 0
      then round(
        100 * coalesce((
          select sum(a.professional_amount)
          from public.appointments a
          where a.professional_id = p.id
            and a.status = 'completed'
            and a.appointment_date >= date_trunc('month', current_date)::date
            and a.appointment_date < (date_trunc('month', current_date) + interval '1 month')::date
        ), 0) / g.target_amount, 1
      )
      else 0
    end as objective_percent,
    (
      select count(*)
      from public.appointments a
      where a.professional_id = p.id
        and a.status = 'completed'
        and a.appointment_date >= date_trunc('month', current_date)::date
        and a.appointment_date < (date_trunc('month', current_date) + interval '1 month')::date
    ) as completed_services
  from public.professionals p
  left join lateral (
    select gg.target_amount
    from public.goals gg
    where gg.professional_id = p.id
      and gg.period_type = 'monthly'
      and gg.period_start >= date_trunc('month', current_date)::date
      and gg.period_start < (date_trunc('month', current_date) + interval '1 month')::date
    order by gg.period_start desc
    limit 1
  ) g on true
  where p.active = true
  order by objective_percent desc, completed_services desc, p.public_name asc;
$$;

revoke all on function public.get_professional_ranking() from public;
grant execute on function public.get_professional_ranking() to authenticated;
