É. PRIVÉ MANAGEMENT — PANEL ADMINISTRATIVO + PORTAL PROFESIONAL

PUBLICACIÓN
1. Descomprime el ZIP.
2. Sube la carpeta EPrive_Management_Completo (la que contiene index.html y assets) a Netlify > sitio privado de administración > Deploys.
3. No lo publiques encima de la web pública de É. Privé.

INCLUYE
Administración: panel, profesionales, tarifas individuales, calendario mensual, citas, disponibilidad, solicitudes, finanzas, gastos, liquidaciones, objetivos, ranking, destacadas y vinculación de usuarios.
Profesionales: espacio personal, agenda propia, envío de disponibilidad, solicitudes de descanso, ganancias propias, objetivos y ranking general sin importes de otras profesionales.

PASOS DE SUPABASE
- NO vuelvas a ejecutar el SQL inicial de creación de tablas.
- Ejecuta professional_ranking_rpc.sql para habilitar el ranking compartido seguro.
- storage_setup.sql es opcional y configura el bucket de fotografías. El bucket es público para lectura; sube solo imágenes autorizadas.

VINCULAR PROFESIONALES
1. Crea la cuenta en Supabase > Authentication > Users.
2. Entra en la app con tu cuenta admin.
3. Abre Usuarios y permisos y vincula esa cuenta con su ficha profesional.
4. La profesional inicia sesión con sus propias credenciales.

SEGURIDAD Y ALCANCE
- No se incluye service_role key ni contraseñas.
- El portal profesional solo consulta sus propias citas, disponibilidad, solicitudes, ganancias, liquidaciones y objetivos; el ranking compartido usa una función agregada que no devuelve importes.
- El comportamiento depende de las políticas RLS ya configuradas en Supabase. Si una consulta devuelve permission denied, no desactives RLS: envía captura para ajustar la política concreta.
- El calendario mensual muestra las citas guardadas. Las vistas de semana/día siguen pendientes de una cuadrícula horaria detallada.
- La app no crea automáticamente usuarios de Auth; se crean en Supabase y se vinculan desde Usuarios.
